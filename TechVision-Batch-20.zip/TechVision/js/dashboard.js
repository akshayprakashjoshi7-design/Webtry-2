import { apiRequest } from "./api-client.js";

const $ = (selector, root = document) => root.querySelector(selector);
const main = $("#workspace-main");
const routeNames = {
  billing: "Plan & Billing",
  dashboard: "Dashboard", academy: "Learning Academy", "code-studio": "Code Studio",
  "cyber-labs": "Cyber Labs", terminal: "Terminal Lab", repositories: "Repositories",
  nexora: "Nexora AI", saved: "Saved items", settings: "Settings", admin: "Admin overview"
};
let currentUser = null;
let apiOnline = false;
let aiHistory = [];
let aiBusy = false;

function esc(value = "") {
  return String(value).replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
}
function toast(message, kind = "info") {
  const node = document.createElement("div");
  node.className = "toast"; node.dataset.kind = kind; node.textContent = message;
  $("#toast-region").append(node);
  window.setTimeout(() => node.remove(), 4200);
}
function pageHeading(eyebrow, title, description, action = "") {
  return `<div class="page-heading"><div><p class="eyebrow">${eyebrow}</p><h1>${title}</h1><p>${description}</p></div>${action}</div>`;
}
function tile(symbol, title, description, route, label = "Open workspace") {
  return `<a class="feature-tile" href="#${route}"><span class="tile-icon">${symbol}</span><strong>${title}</strong><small>${description}</small><span class="muted" style="display:block;margin-top:12px;font-size:.62rem">${label} →</span></a>`;
}
function contentCard(symbol, title, description, status = "PREVIEW") {
  return `<article class="content-card"><div class="card-symbol">${symbol}</div><h3>${title}</h3><p>${description}</p><span class="pill pill-preview">${status}</span></article>`;
}
function guestBanner() {
  if (currentUser) return "";
  return `<div class="notice" style="margin-bottom:18px"><span>ⓘ</span><div><strong>You're viewing the workspace preview.</strong> Sign in to access your account profile. Course data, code execution, AI responses, and remote lab services are not enabled just because this interface is visible. <a href="/login.html" style="color:var(--cyan);text-decoration:underline">Log in</a> or <a href="/signup.html" style="color:var(--cyan);text-decoration:underline">create an account</a>.</div></div>`;
}
function dashboardPage() {
  const name = currentUser?.profile?.displayName || currentUser?.email?.split("@")[0] || "builder";
  return `${pageHeading("YOUR WORKSPACE", `Welcome back, ${esc(name)}.`, "Pick up a learning path, explore the tools, or map out what you want to build next.", `<a class="button button-primary" href="#academy">Explore learning <span>→</span></a>`)}
    ${guestBanner()}
    <section class="dashboard-hero"><div><p class="eyebrow">YOUR NEXT STEP STARTS HERE</p><h2>Make progress, one build at a time.</h2><p>Learn the fundamentals, turn ideas into projects, and practice cybersecurity inside authorized training environments.</p><div class="hero-buttons"><a class="button button-primary" href="#academy">Continue learning <span>→</span></a><a class="button button-secondary" href="#code-studio">Open Code Studio</a></div></div><div class="hero-symbol" aria-hidden="true">✦</div></section>
    <section class="stat-grid" aria-label="Workspace overview"><article class="stat-card"><span class="stat-label">COURSES STARTED</span><strong class="stat-value">—</strong><span class="stat-note">Course service not connected</span></article><article class="stat-card"><span class="stat-label">LESSONS COMPLETED</span><strong class="stat-value">—</strong><span class="stat-note">Progress tracking not connected</span></article><article class="stat-card"><span class="stat-label">PROJECTS</span><strong class="stat-value">—</strong><span class="stat-note">Repository service not connected</span></article><article class="stat-card"><span class="stat-label">STREAK</span><strong class="stat-value">—</strong><span class="stat-note">Activity tracking not connected</span></article></section>
    <div class="dashboard-columns"><section class="panel"><div class="panel-heading"><h3>Learning paths</h3><a href="#academy">View academy →</a></div><p class="panel-subtitle">A curated starting point for practical technology skills.</p><div class="learning-list"><a class="learning-item" href="#academy"><span class="learning-icon">⌘</span><span class="learning-copy"><strong>Cybersecurity fundamentals</strong><small>Threats, defensive concepts, authorization, and safe lab habits</small></span><span class="item-arrow">↗</span></a><a class="learning-item" href="#academy"><span class="learning-icon">{ }</span><span class="learning-copy"><strong>Programming & web development</strong><small>HTML, CSS, JavaScript, Git, and project structure</small></span><span class="item-arrow">↗</span></a><a class="learning-item" href="#academy"><span class="learning-icon">›_</span><span class="learning-copy"><strong>Linux & networking</strong><small>Command-line foundations and networking concepts</small></span><span class="item-arrow">↗</span></a></div>
    <h3 class="section-title">Quick access</h3><div class="quick-grid">${tile("{ }", "Code Studio", "Organize code and project ideas.", "code-studio")}${tile("✦", "Nexora AI", "AI assistant connection is pending.", "nexora")}${tile("⌘", "Cyber Labs", "Scoped learning labs and safety rules.", "cyber-labs")}${tile("▤", "Repositories", "Project organization preview.", "repositories")}</div></section>
    <aside class="panel"><div class="panel-heading"><h3>Workspace status</h3><span class="pill">LIVE CHECK</span></div><div class="activity-list"><div class="activity-item"><span class="activity-mark">●</span><p><strong>Web interface</strong><br>Loaded successfully in your browser.</p></div><div class="activity-item"><span class="activity-mark">${apiOnline ? "●" : "○"}</span><p><strong>API server</strong><br><span id="api-status-copy">${apiOnline ? "Health endpoint responded." : "Checking health endpoint…"}</span></p></div><div class="activity-item"><span class="activity-mark">○</span><p><strong>Database & learning data</strong><br>Connection and migrations need to be configured and verified.</p></div><div class="activity-item"><span class="activity-mark">○</span><p><strong>AI, terminal & execution</strong><br>Not enabled until secure backend services are implemented.</p></div></div><div class="notice" style="margin-top:15px"><span>!</span><div>Never enter real passwords, API keys, or sensitive data into demo fields.</div></div></aside></div>`;
}
function academyPage() {
 return `${pageHeading("LEARN BY BUILDING", "Learning Academy", "Browse sample courses, open lessons, enroll, and track completed lessons. Course data is loaded from the API.")}${guestBanner()}<div class="academy-toolbar"><label class="sr-only" for="academy-search">Search courses</label><input id="academy-search" type="search" placeholder="Search courses by title or topic…"><span id="academy-status" class="muted" role="status">Loading courses…</span></div><div id="academy-courses" class="content-grid"><article class="content-card"><h3>Loading course catalog…</h3><p>Please wait while the API responds.</p></article></div><section id="academy-detail" class="panel academy-detail" hidden></section><div class="notice" style="margin-top:18px"><span>ⓘ</span><div>Sample lessons are educational content, not a certification. Sign in to save enrollments and progress.</div></div>`;
}
function studioPage() {
 return `${pageHeading("BUILD SOMETHING REAL", "Code Studio", "Edit HTML, CSS, and JavaScript locally. Preview runs in a sandboxed iframe; server execution requires a separately configured isolated worker.")}${guestBanner()}<section class="panel studio-panel"><div class="panel-heading"><h2>Editor</h2><span class="pill">LOCAL DRAFT</span></div><div class="studio-toolbar" role="tablist" aria-label="Project files"><button type="button" class="button button-secondary is-active" data-studio-file="html" role="tab" aria-selected="true">index.html</button><button type="button" class="button button-secondary" data-studio-file="css" role="tab" aria-selected="false">style.css</button><button type="button" class="button button-secondary" data-studio-file="js" role="tab" aria-selected="false">script.js</button></div><label class="field-label" for="studio-editor">Current file</label><textarea id="studio-editor" class="studio-editor" spellcheck="false" rows="15" aria-label="Code editor"></textarea><div class="course-card-actions"><button id="studio-preview" class="button button-primary" type="button">Preview locally</button><button id="studio-run-js" class="button button-secondary" type="button">Run JS in isolated worker</button><button id="studio-download" class="button button-secondary" type="button">Download current file</button><button id="studio-reset" class="button button-secondary" type="button">Reset files</button></div><p id="studio-save-status" class="muted" role="status">Drafts are stored in this browser.</p><h3>Local preview</h3><iframe id="studio-preview-frame" title="Sandboxed code preview" sandbox="allow-scripts" referrerpolicy="no-referrer" style="width:100%;min-height:240px;background:white;border:1px solid var(--border);border-radius:10px"></iframe><h3>Isolated worker output</h3><pre id="studio-run-output" class="terminal-output" role="log" aria-live="polite">Worker execution is disabled until configured.</pre></section>`;
}
function labsPage() {
 return `${pageHeading("PRACTICE RESPONSIBLY", "Cyber Labs", "Interactive defensive learning scenarios using fictional sample data. These exercises do not connect to real targets or execute security tools.")}${guestBanner()}<div class="lab-intro panel"><div class="tile-icon">⌘</div><div><h2>Training sandbox</h2><p>Choose a module, inspect the sample scenario, and answer the knowledge check.</p></div><span class="pill">LOCAL SIMULATION</span></div><div class="lab-module-grid"><button type="button" class="lab-module is-active" data-lab-module="triad"><span>◉</span><strong>Security foundations</strong><small>CIA triad and least privilege</small></button><button type="button" class="lab-module" data-lab-module="network"><span>⌁</span><strong>Network basics</strong><small>DNS, IP, ports, protocols</small></button><button type="button" class="lab-module" data-lab-module="logs"><span>▤</span><strong>Defensive log review</strong><small>Recognize suspicious patterns</small></button><button type="button" class="lab-module" data-lab-module="web"><span>▣</span><strong>Web safety</strong><small>Input validation and output encoding</small></button></div><section id="lab-content" class="panel lab-content" aria-live="polite"></section><div class="notice" style="margin-top:18px"><span>!</span><div><strong>Authorization rule:</strong> these exercises use fictional data only. Live scanning, exploitation, credential collection, and remote terminal access are not provided here.</div></div>`;
}
function terminalPage() {
  if (!currentUser) return `${pageHeading("A CONTROLLED LEARNING ENVIRONMENT", "Terminal Lab", "A safe command simulator for learning basic command-line concepts.")}${guestBanner()}<section class="empty-state"><h2>Sign in to start a practice session</h2><p>This simulator never invokes a real operating-system shell.</p><a class="button button-primary" href="/login.html">Log in</a></section>`;
  return `${pageHeading("A CONTROLLED LEARNING ENVIRONMENT", "Terminal Lab", "Learn command-line basics in a simulated environment. Commands do not run on your device or the server.")}
  <section class="panel terminal-panel"><div class="panel-heading"><h2>Safe command simulator</h2><span class="pill">SIMULATED</span></div><p class="panel-subtitle">Try <code>help</code>, <code>pwd</code>, <code>ls</code>, <code>whoami</code>, or <code>cat README.txt</code>.</p><div id="terminal-output" class="terminal-output" role="log" aria-live="polite"><p>TechVision Terminal Lab v1.0</p><p>Type <strong>help</strong> to list simulated commands.</p></div><form id="terminal-form" class="terminal-form"><label for="terminal-command">learner@techvision:~$</label><input id="terminal-command" name="command" maxlength="160" autocomplete="off" required><button class="button button-primary" type="submit">Run simulation</button></form><p id="terminal-status" class="muted" role="status"></p><button class="button button-secondary" type="button" id="terminal-clear">Clear display</button></section><div class="notice" style="margin-top:16px"><span>!</span><div>Not a real shell. File changes, network access, privilege escalation, and arbitrary commands are not available.</div></div>`;
}
function repositoriesPage() {
 if (!currentUser) return `${pageHeading("YOUR PROJECTS", "Repositories", "Create private project records and organize ideas.")}${guestBanner()}<a class="button button-primary" href="/login.html">Log in to continue</a>`;
 return `${pageHeading("YOUR PROJECTS", "Repositories", "Manage project metadata. File storage, Git history, and remote hosting are not connected.", `<button class="button button-primary" id="project-new" type="button">＋ New project</button>`)}<form id="project-form" class="panel settings-form" hidden><h2>Create project</h2><label class="field-label">Project name<input name="name" maxlength="180" required minlength="2"></label><label class="field-label">Description<textarea name="description" maxlength="2000"></textarea></label><label class="field-label">Language<input name="language" maxlength="40" placeholder="JavaScript, Python…"></label><label class="field-label">Visibility<select name="visibility"><option value="PRIVATE">Private</option><option value="UNLISTED">Unlisted</option><option value="PUBLIC">Public</option></select></label><div class="form-actions"><button class="button button-primary" type="submit">Create project</button><button class="button button-secondary" type="button" id="project-cancel">Cancel</button></div><p id="project-status" class="muted" role="status"></p></form><div id="project-list" class="content-grid"><section class="empty-state"><h2>Loading projects…</h2></section></div><p class="muted" id="project-note"></p>`;
}
function nexoraPage() {
  const intro = pageHeading("YOUR LEARNING COMPANION", "Nexora AI", "Ask about programming, Linux, networking, study planning, or defensive cybersecurity. Verify important answers before relying on them.");
  if (!currentUser) return `${intro}${guestBanner()}<section class="empty-state"><div class="empty-icon">✦</div><h2>Sign in to use Nexora AI</h2><p>AI conversations require an authenticated account. Avoid sending passwords, API keys, private identifiers, or other sensitive information.</p><a class="button button-primary" href="/login.html">Log in to continue</a></section>`;
  return `${intro}<section class="nexora-layout"><div class="nexora-chat panel"><div class="nexora-chat-head"><div class="nexora-avatar">✦</div><div><strong>Nexora learning assistant</strong><p>Server-connected AI · responses may be imperfect</p></div><span class="pill">BETA</span></div><div class="nexora-messages" id="nexora-messages" aria-live="polite" aria-label="Conversation"><article class="nexora-message assistant"><span class="message-role">NEXORA</span><p>Hi! What are you learning today? I can explain a concept, help plan a study session, or review code you provide.</p></article></div><p class="nexora-status" id="nexora-status" role="status">Do not share secrets or personal information.</p><form class="nexora-composer" id="nexora-form"><label class="sr-only" for="nexora-input">Message Nexora AI</label><textarea id="nexora-input" name="message" maxlength="4000" rows="2" placeholder="Ask a question…" required></textarea><button class="button button-primary" type="submit" id="nexora-send">Send <span aria-hidden="true">↑</span></button></form><div class="nexora-footnote">AI can make mistakes. Check important information. Requests are sent to the configured AI provider.</div></div><aside class="nexora-side"><section class="panel"><h3>Try asking</h3><div class="nexora-prompts"><button type="button" data-ai-prompt="Explain DNS in simple terms with a small example.">Explain DNS simply <span>↗</span></button><button type="button" data-ai-prompt="Create a 7-day beginner study plan for Linux fundamentals.">Build a Linux study plan <span>↗</span></button><button type="button" data-ai-prompt="Explain input validation and output encoding in web security, with a safe example.">Learn web security basics <span>↗</span></button><button type="button" data-ai-prompt="Review this beginner JavaScript snippet and explain improvements: ">Review my code <span>↗</span></button></div></section><section class="panel nexora-privacy"><h3>Use AI thoughtfully</h3><p>Keep prompts focused and remove personal or confidential details before sending them.</p><p>For cybersecurity questions, work only in systems you own or have explicit permission to test.</p><span class="pill pill-preview">LEARNING MODE</span></section></aside></section>`;
}
function savedPage() {
 if (!currentUser) return `${pageHeading("YOUR PERSONAL LIBRARY", "Saved items", "Save course and project references for later.")}${guestBanner()}`;
 return `${pageHeading("YOUR PERSONAL LIBRARY", "Saved items", "Your saved courses and projects. You can remove an item at any time.")}<div id="saved-list" class="content-grid"><section class="empty-state"><h2>Loading saved items…</h2></section></div><p class="muted" id="saved-status" role="status"></p>`;
}
function settingsPage() {
  const profile = currentUser?.profile || {};
  if (!currentUser) return `${pageHeading("ACCOUNT PREFERENCES", "Settings", "Sign in to manage your profile.")}${guestBanner()}<section class="empty-state"><div class="empty-icon">⚙</div><h2>Sign in to manage settings</h2><p>Profile settings are available to authenticated users.</p><a class="button button-primary" href="/login.html">Log in</a></section>`;
  return `${pageHeading("ACCOUNT PREFERENCES", "Settings", "Update the display name and short bio associated with your TechVision account.")}
    <section class="panel"><div class="panel-heading"><h3>Public profile</h3><span class="pill">ACCOUNT</span></div><form class="settings-form" id="profile-form"><label class="field-label">Display name<input name="displayName" minlength="2" maxlength="60" value="${esc(profile.displayName || "")}" required></label><label class="field-label">Email address<input value="${esc(currentUser.email || "")}" disabled></label><label class="field-label">Short bio<textarea name="bio" maxlength="500" placeholder="What are you learning or building?">${esc(profile.bio || "")}</textarea></label><p class="muted" style="font-size:.68rem;margin:0">Email changes, password reset, MFA, and verification flows are not available yet.</p><div class="form-actions"><button class="button button-primary" type="submit">Save profile</button><button class="button button-secondary" id="logout-button" type="button">Log out</button></div><p id="profile-status" class="muted" aria-live="polite" style="font-size:.72rem;margin:0"></p></form></section>`;
}
function adminPage() { if (!currentUser) return `${pageHeading("PLATFORM CONTROL", "Admin overview", "Restricted platform management area.")}${guestBanner()}`; return `${pageHeading("PLATFORM CONTROL", "Admin overview", "Read-only platform statistics and recent audit events. Requires the ADMIN role.")}<div id="admin-overview" class="content-grid"><section class="empty-state"><h2>Checking permissions…</h2></section></div><p id="admin-status" class="muted" role="status"></p>`; }


function billingPage() { return `${pageHeading("YOUR PLAN", "Plan & Billing", "View your current plan and request a checkout session when a payment provider is configured.")}${guestBanner()}<section class="panel"><div class="panel-heading"><h3>Free learner plan</h3><span class="pill">DEFAULT</span></div><p class="panel-subtitle">Paid subscriptions are not activated from a browser click. A verified payment-provider webhook is required to change entitlement.</p><div class="course-card-actions"><button class="button button-primary" type="button" id="billing-refresh">Refresh plan</button><button class="button button-secondary" type="button" id="billing-checkout">Explore paid plans</button></div><p id="billing-status" class="muted" role="status"></p></section>`; }

const pages = { billing: billingPage, dashboard: dashboardPage, academy: academyPage, "code-studio": studioPage, "cyber-labs": labsPage, terminal: terminalPage, repositories: repositoriesPage, nexora: nexoraPage, saved: savedPage, settings: settingsPage, admin: adminPage };
function renderRoute() {
  const route = location.hash.slice(1) || "dashboard";
  const safeRoute = Object.hasOwn(pages, route) ? route : "dashboard";
  if (!location.hash) history.replaceState(null, "", "#dashboard");
  if (safeRoute !== "nexora") aiHistory = [];
  $("#breadcrumb-current").textContent = routeNames[safeRoute];
  document.title = `${routeNames[safeRoute]} — TechVision`;
  document.querySelectorAll("[data-route]").forEach(link => link.classList.toggle("is-active", link.dataset.route === safeRoute));
  main.innerHTML = pages[safeRoute]();
  if (safeRoute === "code-studio") initStudio();
  if (safeRoute === "academy") loadAcademy();
  if (safeRoute === "terminal") initTerminal();
  if (safeRoute === "repositories") loadProjects();
  if (safeRoute === "saved") loadSavedItems();
  if (safeRoute === "admin") loadAdmin();
  main.focus({ preventScroll: true });
}
function setUser(user) {
  currentUser = user || null;
  const name = currentUser?.profile?.displayName || currentUser?.email?.split("@")[0] || "Guest mode";
  $("#sidebar-user-name").textContent = name;
  $("#sidebar-user-email").textContent = currentUser?.email || "Sign in to sync progress";
  $("#user-avatar").textContent = (name[0] || "G").toUpperCase();
  $("#topbar-auth-link").textContent = currentUser ? "Log out" : "Log in";
  $("#topbar-auth-link").href = currentUser ? "#logout" : "/login.html";
}
async function loadAccount() {
  try { const result = await apiRequest("/auth/me"); setUser(result.data.user); }
  catch (error) { if (error.status === 401) setUser(null); else setUser(null); }
  renderRoute();
}
async function logout() {
  try { await apiRequest("/auth/logout", { method: "POST" }); setUser(null); toast("You have been logged out.", "success"); renderRoute(); }
  catch { toast("Could not contact the server to log out. Please retry when connected.", "error"); }
}
$("#sidebar-toggle").addEventListener("click", () => {
  const opened = $("#app-sidebar").classList.toggle("is-open");
  $("#sidebar-scrim").classList.toggle("is-visible", opened);
  $("#sidebar-toggle").setAttribute("aria-expanded", String(opened));
});
function closeSidebar() { $("#app-sidebar").classList.remove("is-open"); $("#sidebar-scrim").classList.remove("is-visible"); $("#sidebar-toggle").setAttribute("aria-expanded", "false"); }
$("#sidebar-scrim").addEventListener("click", closeSidebar);
$("#workspace-nav").addEventListener("click", event => { if (event.target.closest("a")) closeSidebar(); });
$("#quick-start").addEventListener("click", () => { location.hash = "#code-studio"; toast("Code Studio is currently a UI preview."); });
$("#user-menu").addEventListener("click", () => currentUser ? toast(`Signed in as ${currentUser.email}. Open Settings to edit your profile.`) : (location.href = "/login.html"));
$("#help-button").addEventListener("click", () => { location.hash = "#nexora"; });
$("#topbar-auth-link").addEventListener("click", event => { if (currentUser) { event.preventDefault(); logout(); } });
window.addEventListener("hashchange", () => { renderRoute(); closeSidebar(); });
main.addEventListener("click", event => {
  const button = event.target.closest("[data-toast]");
  if (button) toast(button.dataset.toast);
  if (event.target.closest("#logout-button")) logout();
});
const STUDIO_STARTER = {
 html: `<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>My TechVision Project</title>\n</head>\n<body>\n<main class="card"><p class="eyebrow">HELLO, BUILDER</p><h1>Build with purpose.</h1><p>Edit this page, then select Preview.</p><button id="hello-button" type="button">Try interaction</button><p id="message" aria-live="polite"></p></main>\n</body>\n</html>`,
 css: `:root { font-family: system-ui, sans-serif; color: #172033; background: #eef4ff; }\nbody { margin: 0; min-height: 100vh; display: grid; place-items: center; }\n.card { width: min(560px, 86vw); padding: 2rem; border-radius: 20px; background: white; box-shadow: 0 18px 60px #1c3b661c; }\n.eyebrow { color: #2563eb; letter-spacing: .14em; font-size: .75rem; font-weight: 700; }\nbutton { border: 0; border-radius: 9px; padding: .75rem 1rem; background: #2563eb; color: white; cursor: pointer; }`,
 js: `document.querySelector("#hello-button")?.addEventListener("click", () => {\n const message = document.querySelector("#message");\n if (message) message.textContent = "Great work — your JavaScript is running in the preview.";\n});`
};
let studioFiles = { ...STUDIO_STARTER };
let studioCurrentFile = "html";
function studioStorageKey() { return currentUser?.id ? `tv-studio-v1:${currentUser.id}` : "tv-studio-v1:guest"; }
function loadStudioFiles() {
 try { const saved = JSON.parse(localStorage.getItem(studioStorageKey()) || "null"); studioFiles = saved && typeof saved === "object" ? { ...STUDIO_STARTER, ...saved } : { ...STUDIO_STARTER }; }
 catch { studioFiles = { ...STUDIO_STARTER }; }
}
function persistStudioFiles() {
 try { localStorage.setItem(studioStorageKey(), JSON.stringify(studioFiles)); const status = $("#studio-save-status"); if (status) status.textContent = "Saved in this browser"; }
 catch { const status = $("#studio-save-status"); if (status) status.textContent = "Browser storage unavailable"; }
}
function setStudioFile(file) {
 if (!Object.hasOwn(STUDIO_STARTER, file)) return;
 const editor = $("#studio-editor"); if (editor) studioFiles[studioCurrentFile] = editor.value;
 studioCurrentFile = file;
 document.querySelectorAll("[data-studio-file]").forEach(tab => { const active = tab.dataset.studioFile === file; tab.classList.toggle("is-active", active); tab.setAttribute("aria-selected", String(active)); });
 if (editor) { editor.value = studioFiles[file] ?? STUDIO_STARTER[file]; editor.dataset.file = file; }
 persistStudioFiles();
}
function renderStudioPreview() {
 const editor = $("#studio-editor"); if (editor) studioFiles[studioCurrentFile] = editor.value; persistStudioFiles();
 const frame = $("#studio-preview-frame"); if (!frame) return;
 const css = String(studioFiles.css || "").replace(/<\/style/gi, "<\\/style");
 const js = String(studioFiles.js || "").replace(/<\/script/gi, "<\\/script");
 let doc = studioFiles.html || STUDIO_STARTER.html;
 if (!/<html[\s>]/i.test(doc)) doc = `<!doctype html><html><head><meta charset="utf-8"></head><body>${doc}</body></html>`;
 doc = doc.includes("</head>") ? doc.replace("</head>", `<style>${css}</style></head>`) : `<style>${css}</style>${doc}`;
 doc = doc.includes("</body>") ? doc.replace("</body>", `<script>${js}\n<\/script></body>`) : `${doc}<script>${js}\n<\/script>`;
 frame.srcdoc = doc;
}
function initStudio() {
 if (location.hash !== "#code-studio" || !$("#studio-editor")) return;
 loadStudioFiles(); studioCurrentFile = "html"; setStudioFile("html");
 const editor = $("#studio-editor"); editor.addEventListener("input", () => { studioFiles[studioCurrentFile] = editor.value; persistStudioFiles(); });
 $("#studio-preview").addEventListener("click", renderStudioPreview);
 $("#studio-reset").addEventListener("click", () => { if (!window.confirm("Reset the three local project files to the starter template?")) return; studioFiles = { ...STUDIO_STARTER }; setStudioFile("html"); renderStudioPreview(); });
 $("#studio-download").addEventListener("click", () => { studioFiles[studioCurrentFile] = editor.value; const ext = studioCurrentFile === "html" ? "html" : studioCurrentFile === "css" ? "css" : "js"; const url = URL.createObjectURL(new Blob([editor.value], { type: "text/plain;charset=utf-8" })); const a = document.createElement("a"); a.href = url; a.download = `index.${ext}`; a.click(); URL.revokeObjectURL(url); });
 document.querySelectorAll("[data-studio-file]").forEach(tab => tab.addEventListener("click", () => setStudioFile(tab.dataset.studioFile)));
 const runButton=$("#studio-run-js"); if(runButton)runButton.addEventListener("click",async()=>{studioFiles[studioCurrentFile]=editor.value;const output=$("#studio-run-output");if(studioCurrentFile!=="js"){output.textContent="Select script.js before running JavaScript.";return;}if(!currentUser){output.textContent="Log in to request isolated execution.";return;}runButton.disabled=true;output.textContent="Submitting to isolated worker…";try{const result=await apiRequest("/execution/jobs",{method:"POST",body:JSON.stringify({language:"javascript",source:studioFiles.js})});const job=result.data.job;output.textContent=[`status: ${job.status}`,`exit code: ${job.exitCode??"unknown"}`,job.stdout||"",job.stderr||""].filter(Boolean).join("\n");}catch(error){output.textContent=error.message;}finally{runButton.disabled=false;}});
 renderStudioPreview();
}

const LAB_MODULES={
triad:{title:"Security foundations",intro:"A fictional student portal stores grades and course schedules.",scenario:"Students should only see their own grades, authorized staff changes should be traceable, and the portal should remain available during registration.",choices:[{label:"Restrict each student to their own records",explain:"Correct: access controls help protect confidentiality."},{label:"Keep a change log for grade edits",explain:"Correct: traceable changes support integrity and accountability."},{label:"Test backups and recovery procedures",explain:"Correct: tested recovery helps maintain availability."}],question:"Which principle is most directly supported by a tested backup and recovery plan?",options:["Confidentiality","Integrity","Availability"],correct:2,explanation:"Availability means authorized people can use a system when needed."},
network:{title:"Network basics",intro:"A fictional learning app loads by IP address but not by hostname.",scenario:"The host is reachable by IP, but the name does not resolve. Start with normal configuration checks rather than probing unrelated systems.",question:"What is the most relevant first area to inspect?",options:["DNS resolver configuration and lookup results","Password hashes in the database","The website's CSS files"],correct:0,explanation:"When IP connectivity works but a hostname fails, DNS resolution is a sensible first diagnostic."},
logs:{title:"Defensive log review",intro:"These are made-up sign-in events from a training application.",scenario:"09:00 — successful sign-in for demo.user. 09:02 — several failed sign-ins for demo.user. 09:03 — successful sign-in from the same test workstation.",question:"What is the most responsible next step?",options:["Check approved logs and sign-in context, then follow the incident playbook","Publicly post the user's details","Delete the log entries to reduce noise"],correct:0,explanation:"Correlate approved telemetry, preserve evidence, and follow the incident process. Avoid premature conclusions."},
web:{title:"Web safety",intro:"A feedback form displays a visitor's comment on a page.",scenario:"A developer inserts the comment as HTML instead of rendering it as plain text. Treat the comment as untrusted input.",question:"Which approach is safer for displaying plain text?",options:["Use textContent or an equivalent safe text API","Concatenate it into innerHTML without encoding","Trust it because the browser sent it"],correct:0,explanation:"Render plain text as text and validate on the server. Client-side checks alone are not a security boundary."}};
let activeLabModule="triad";
function renderLabModule(key){const m=LAB_MODULES[key];if(!m)return;activeLabModule=key;document.querySelectorAll("[data-lab-module]").forEach(b=>b.classList.toggle("is-active",b.dataset.labModule===key));const target=$("#lab-content");if(!target)return;target.innerHTML=`<p class="eyebrow">SIMULATED EXERCISE</p><h2>${esc(m.title)}</h2><p>${esc(m.intro)}</p><div class="lab-scenario"><strong>Scenario</strong><p>${esc(m.scenario)}</p></div>${m.choices?`<div class="lab-concepts"><h3>Identify the principle</h3>${m.choices.map((c,i)=>`<button type="button" class="lab-concept" data-lab-concept="${i}"><span>${i+1}</span>${esc(c.label)}</button>`).join("")}<p id="lab-concept-feedback" class="lab-feedback" aria-live="polite"></p></div>`:""}<div class="lab-question"><h3>${esc(m.question)}</h3><form id="lab-quiz-form"><fieldset><legend class="sr-only">Choose the best answer</legend>${m.options.map((o,i)=>`<label class="lab-answer"><input type="radio" name="answer" value="${i}" required><span>${esc(o)}</span></label>`).join("")}</fieldset><button type="submit" class="button button-primary">Check answer</button><p id="lab-quiz-feedback" class="lab-feedback" aria-live="polite"></p></form></div>`}
function initLabs(){if(location.hash!=="#cyber-labs"||!$("#lab-content"))return;renderLabModule("triad");document.querySelectorAll("[data-lab-module]").forEach(b=>b.addEventListener("click",()=>renderLabModule(b.dataset.labModule)));$("#lab-content").addEventListener("click",e=>{const b=e.target.closest("[data-lab-concept]");if(!b)return;const c=LAB_MODULES[activeLabModule].choices?.[Number(b.dataset.labConcept)];const f=$("#lab-concept-feedback");if(f&&c)f.textContent=c.explain});$("#lab-content").addEventListener("submit",e=>{if(e.target.id!=="lab-quiz-form")return;e.preventDefault();const selected=new FormData(e.target).get("answer");const m=LAB_MODULES[activeLabModule];const f=$("#lab-quiz-feedback");if(f)f.textContent=Number(selected)===m.correct?`Correct. ${m.explanation}`:`Not quite. ${m.explanation}`})}

let academyCourses=[];let academyEnrolled=new Set();let academyProgress=new Set();
function renderAcademyCourses(filter=""){const target=$("#academy-courses");if(!target)return;const term=filter.trim().toLowerCase();const shown=academyCourses.filter(c=>`${c.title} ${c.description} ${c.category} ${c.level}`.toLowerCase().includes(term));target.innerHTML=shown.length?shown.map(c=>`<article class="content-card academy-course"><div class="course-card-top"><span class="tile-icon">◈</span><span class="pill">${esc(c.level)}</span></div><p class="eyebrow">${esc(c.category)}</p><h3>${esc(c.title)}</h3><p>${esc(c.description)}</p><div class="course-meta"><span>${(c.modules||[]).length} module(s)</span><span>${(c.modules||[]).reduce((n,m)=>n+(m.lessons||[]).length,0)} lessons</span></div><div class="course-card-actions"><button class="button button-secondary" data-course-open="${esc(c.slug)}" type="button">View lessons</button>${currentUser?`<button class="button button-primary" data-course-enroll="${esc(c.id)}" type="button">${academyEnrolled.has(c.id)?"Enrolled ✓":"Enroll"}</button>`:`<a class="button button-primary" href="/login.html">Log in to enroll</a>`}</div></article>`).join(""):`<section class="empty-state"><h2>No matching courses</h2><p>Try another search term.</p></section>`;const status=$("#academy-status");if(status)status.textContent=`${shown.length} course${shown.length===1?"":"s"}`}
async function loadAcademy(){if(location.hash!=="#academy"||!$("#academy-courses"))return;try{const r=await apiRequest("/learning/courses");academyCourses=r.data.courses||[];if(currentUser){try{const m=await apiRequest("/learning/me");academyEnrolled=new Set((m.data.enrollments||[]).map(e=>e.courseId));academyProgress=new Set((m.data.progress||[]).filter(x=>x.completedAt).map(x=>x.lessonId))}catch{}}renderAcademyCourses($("#academy-search")?.value||"")}catch(e){$("#academy-courses").innerHTML=`<section class="empty-state"><h2>Course catalog unavailable</h2><p>${esc(e.message)}. Check database configuration, migrations, and seed.</p></section>`;const status=$("#academy-status");if(status)status.textContent="API unavailable"}}
function renderCourseDetail(course){const panel=$("#academy-detail");if(!panel)return;panel.hidden=false;panel.innerHTML=`<div class="panel-heading"><div><p class="eyebrow">COURSE CONTENT</p><h2>${esc(course.title)}</h2><p class="panel-subtitle">${esc(course.description)}</p></div><button type="button" class="button button-secondary" id="academy-close-detail">Close</button></div>${(course.modules||[]).map(m=>`<section class="course-module"><h3>${esc(m.title)}</h3><div class="lesson-list">${(m.lessons||[]).map(l=>`<article class="lesson-item"><div><strong>${esc(l.title)}</strong><p>${esc(l.durationMin)} min · ${esc(l.content||"")}</p></div><button type="button" class="button button-secondary" data-lesson-complete="${esc(l.id)}" ${!currentUser||!academyEnrolled.has(course.id)?"disabled":""}>${academyProgress.has(l.id)?"Completed ✓":"Mark complete"}</button></article>`).join("")}</div></section>`).join("")}`;panel.scrollIntoView({behavior:"smooth",block:"start"})}
async function handleAcademyClick(event){const enroll=event.target.closest("[data-course-enroll]");if(enroll){enroll.disabled=true;try{await apiRequest("/learning/enroll",{method:"POST",body:JSON.stringify({courseId:enroll.dataset.courseEnroll})});academyEnrolled.add(enroll.dataset.courseEnroll);renderAcademyCourses($("#academy-search")?.value||"");toast("You're enrolled in this course.","success")}catch(e){toast(e.message,"error")}return}const open=event.target.closest("[data-course-open]");if(open){const c=academyCourses.find(x=>x.slug===open.dataset.courseOpen);if(c)try{const r=await apiRequest(`/learning/courses/${encodeURIComponent(c.slug)}`);renderCourseDetail(r.data.course)}catch(e){toast(e.message,"error")}return}const lesson=event.target.closest("[data-lesson-complete]");if(lesson){lesson.disabled=true;try{await apiRequest("/learning/progress",{method:"PUT",body:JSON.stringify({lessonId:lesson.dataset.lessonComplete,completed:true})});academyProgress.add(lesson.dataset.lessonComplete);const c=academyCourses.find(x=>(x.modules||[]).some(m=>(m.lessons||[]).some(l=>l.id===lesson.dataset.lessonComplete)));if(c){const r=await apiRequest(`/learning/courses/${encodeURIComponent(c.slug)}`);renderCourseDetail(r.data.course)}toast("Lesson progress saved.","success")}catch(e){lesson.disabled=false;toast(e.message,"error")}}}
main.addEventListener("click",event=>{if(event.target.closest("#academy-close-detail")){const d=$("#academy-detail");if(d)d.hidden=true;return}if(event.target.closest("[data-course-enroll],[data-course-open],[data-lesson-complete]"))handleAcademyClick(event)});main.addEventListener("input",event=>{if(event.target.id==="academy-search")renderAcademyCourses(event.target.value)});
async function initTerminal() {
 const form=$("#terminal-form"); if(!form)return; const output=$("#terminal-output");
 try { await apiRequest("/terminal/sessions",{method:"POST",body:JSON.stringify({})}); } catch(e) { const st=$("#terminal-status"); if(st)st.textContent=e.message; }
 form.addEventListener("submit",async e=>{e.preventDefault();const input=$("#terminal-command");const command=input.value.trim();if(!command)return;const line=document.createElement("p");line.textContent=`learner@techvision:~$ ${command}`;output.append(line);input.value="";try{const r=await apiRequest("/terminal/command",{method:"POST",body:JSON.stringify({command})});if(r.data.output==="__CLEAR__"){output.replaceChildren();return}const result=document.createElement("p");result.textContent=r.data.output;output.append(result)}catch(err){const result=document.createElement("p");result.textContent=err.message;output.append(result)}output.scrollTop=output.scrollHeight;});
 $("#terminal-clear")?.addEventListener("click",()=>output.replaceChildren());
}
async function loadProjects(){const target=$("#project-list");if(!target)return;try{const r=await apiRequest("/projects");const items=r.data.projects||[];target.innerHTML=items.length?items.map(p=>`<article class="content-card"><div class="course-card-top"><span class="tile-icon">▤</span><span class="pill">${esc(p.visibility)}</span></div><h3>${esc(p.name)}</h3><p>${esc(p.description||"No description")}</p><div class="course-meta"><span>${esc(p.language||"Unspecified language")}</span><span>Updated ${new Date(p.updatedAt).toLocaleDateString()}</span></div><div class="course-card-actions"><button class="button button-secondary" type="button" data-project-save="${esc(p.id)}">Save</button><button class="button button-secondary" type="button" data-project-delete="${esc(p.id)}">Delete</button></div></article>`).join(""):`<section class="empty-state"><h2>No projects yet</h2><p>Create a project record to get started.</p></section>`;$("#project-note").textContent=r.data.notice||"";}catch(e){target.innerHTML=`<section class="empty-state"><h2>Projects unavailable</h2><p>${esc(e.message)}</p></section>`}}
async function loadSavedItems(){const target=$("#saved-list");if(!target)return;try{const r=await apiRequest("/personal/bookmarks");const items=r.data.bookmarks||[];target.innerHTML=items.length?items.map(b=>`<article class="content-card"><p class="eyebrow">${esc(b.targetType)}</p><h3>${esc(b.targetId)}</h3><p>Saved ${new Date(b.createdAt).toLocaleDateString()}</p><button class="button button-secondary" type="button" data-bookmark-remove="${esc(b.targetType)}|${esc(b.targetId)}">Remove</button></article>`).join(""):`<section class="empty-state"><h2>Nothing saved yet</h2><p>Use Save on a project to add it to your library.</p><a class="button button-secondary" href="#repositories">Open projects</a></section>`;}catch(e){target.innerHTML=`<section class="empty-state"><h2>Saved items unavailable</h2><p>${esc(e.message)}</p></section>`}}
async function loadAdmin(){const target=$("#admin-overview");if(!target)return;try{const r=await apiRequest("/admin/overview");const s=r.data.stats;target.innerHTML=Object.entries(s).map(([k,v])=>`<article class="stat-card"><span class="stat-label">${esc(k.replace(/[A-Z]/g,m=>" "+m).toUpperCase())}</span><strong class="stat-value">${esc(v)}</strong></article>`).join("")+`<section class="panel"><h2>Recent audit events</h2>${(r.data.recentAudit||[]).map(a=>`<p>${esc(a.action)} · ${esc(a.actor?.email||"system")} · ${new Date(a.createdAt).toLocaleString()}</p>`).join("")||"<p>No events recorded.</p>"}</section>`;}catch(e){target.innerHTML=`<section class="empty-state"><h2>Admin access unavailable</h2><p>${esc(e.message)}</p><p>Only accounts assigned the ADMIN role can view this page.</p></section>`}}
main.addEventListener("click",async e=>{if(e.target.closest("#billing-refresh")){const status=$("#billing-status");try{const r=await apiRequest("/billing/me");status.textContent=`Plan: ${r.data.subscription?.plan||"FREE"} · Status: ${r.data.subscription?.status||"NONE"}`}catch(err){status.textContent=err.message}return}if(e.target.closest("#billing-checkout")){const status=$("#billing-status");try{const r=await apiRequest("/billing/checkout",{method:"POST",body:JSON.stringify({plan:"PRO_MONTHLY"})});if(r.data.url)location.href=r.data.url;else status.textContent=r.data.message||"Checkout is not configured."}catch(err){status.textContent=err.message}return}if(e.target.closest("#project-new")){const f=$("#project-form");if(f)f.hidden=false;return}if(e.target.closest("#project-cancel")){const f=$("#project-form");if(f)f.hidden=true;return}const del=e.target.closest("[data-project-delete]");if(del){if(!confirm("Delete this project metadata? This cannot be undone."))return;try{await apiRequest(`/projects/${encodeURIComponent(del.dataset.projectDelete)}`,{method:"DELETE"});toast("Project deleted.","success");loadProjects()}catch(err){toast(err.message,"error")}return}const save=e.target.closest("[data-project-save]");if(save){try{await apiRequest("/personal/bookmarks",{method:"POST",body:JSON.stringify({targetType:"PROJECT",targetId:save.dataset.projectSave})});toast("Project saved to your library.","success")}catch(err){toast(err.message,"error")}return}const remove=e.target.closest("[data-bookmark-remove]");if(remove){const [targetType,targetId]=remove.dataset.bookmarkRemove.split("|");try{await apiRequest("/personal/bookmarks",{method:"DELETE",body:JSON.stringify({targetType,targetId})});loadSavedItems()}catch(err){toast(err.message,"error")}}});
main.addEventListener("submit",async e=>{if(e.target.id!=="project-form")return;e.preventDefault();const data=Object.fromEntries(new FormData(e.target));const status=$("#project-status");try{await apiRequest("/projects",{method:"POST",body:JSON.stringify(data)});e.target.reset();e.target.hidden=true;toast("Project created.","success");loadProjects()}catch(err){if(status)status.textContent=err.message}});

function appendAiMessage(role, content) {
  const list = $("#nexora-messages");
  if (!list) return;
  const article = document.createElement("article");
  article.className = `nexora-message ${role}`;
  const label = document.createElement("span");
  label.className = "message-role";
  label.textContent = role === "user" ? "YOU" : role === "error" ? "NOTICE" : "NEXORA";
  const paragraph = document.createElement("p");
  paragraph.textContent = content;
  article.append(label, paragraph);
  list.append(article);
  list.scrollTop = list.scrollHeight;
}

async function sendAiMessage(rawMessage) {
  const message = String(rawMessage || "").trim();
  if (!message || aiBusy) return;
  const input = $("#nexora-input");
  const button = $("#nexora-send");
  const status = $("#nexora-status");
  aiBusy = true;
  appendAiMessage("user", message);
  if (input) { input.value = ""; input.disabled = true; }
  if (button) { button.disabled = true; button.textContent = "Thinking…"; }
  if (status) status.textContent = "Nexora is preparing a response…";
  try {
    const result = await apiRequest("/ai/chat", { method: "POST", body: JSON.stringify({ message, history: aiHistory.slice(-12) }) });
    const reply = result?.data?.text;
    if (typeof reply !== "string" || !reply.trim()) throw new Error("The AI returned an empty response.");
    aiHistory.push({ role: "user", content: message }, { role: "assistant", content: reply });
    aiHistory = aiHistory.slice(-12);
    appendAiMessage("assistant", reply);
    if (status) status.textContent = "Response received. Check important information.";
  } catch (error) {
    appendAiMessage("error", error.message || "Nexora could not respond. Please try again.");
    if (status) status.textContent = "Message was not answered. You can try again.";
  } finally {
    aiBusy = false;
    const currentInput = $("#nexora-input");
    const currentButton = $("#nexora-send");
    if (currentInput) { currentInput.disabled = false; currentInput.focus(); }
    if (currentButton) { currentButton.disabled = false; currentButton.innerHTML = 'Send <span aria-hidden="true">↑</span>'; }
  }
}

main.addEventListener("click", event => {
  const promptButton = event.target.closest("[data-ai-prompt]");
  if (!promptButton) return;
  const input = $("#nexora-input");
  if (!input || aiBusy) return;
  input.value = promptButton.dataset.aiPrompt || "";
  input.focus();
  input.setSelectionRange(input.value.length, input.value.length);
});

main.addEventListener("submit", async event => {
  if (event.target.id === "nexora-form") {
    event.preventDefault();
    await sendAiMessage(new FormData(event.target).get("message"));
    return;
  }
  if (event.target.id !== "profile-form") return;
  event.preventDefault();
  const form = event.target; const submit = form.querySelector('[type="submit"]'); const status = $("#profile-status");
  const data = Object.fromEntries(new FormData(form)); submit.disabled = true; submit.textContent = "Saving…"; status.textContent = "";
  try {
    const result = await apiRequest("/auth/profile", { method: "PATCH", body: JSON.stringify(data) });
    setUser(result.data.user); status.textContent = "Profile saved."; toast("Profile updated.", "success"); renderRoute();
  } catch (error) { status.textContent = error.message; toast(error.message, "error"); }
  finally { const next = form.querySelector('[type="submit"]'); if (next) { next.disabled = false; next.textContent = "Save profile"; } }
});
apiRequest("/health").then(result => {
  apiOnline = result.status === "ok";
  const indicator = $("#api-indicator"); indicator.dataset.status = apiOnline ? "online" : "offline";
  indicator.querySelector("span").textContent = apiOnline ? "API reachable" : "API unavailable";
  const statusCopy = $("#api-status-copy"); if (statusCopy) statusCopy.textContent = "Health endpoint responded.";
}).catch(() => {
  const indicator = $("#api-indicator"); indicator.dataset.status = "offline"; indicator.querySelector("span").textContent = "API unavailable";
  const statusCopy = $("#api-status-copy"); if (statusCopy) statusCopy.textContent = "Could not confirm API availability.";
});
loadAccount();
