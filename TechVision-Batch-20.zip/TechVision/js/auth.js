import { apiRequest } from "./api-client.js";
const form = document.querySelector("#auth-form");
const status = document.querySelector("#auth-status");
if (form && status) {
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const submit = form.querySelector('[type="submit"]');
    const values = Object.fromEntries(new FormData(form));
    const mode = form.dataset.mode;
    const endpoint = mode === "register" ? "/auth/register" : "/auth/login";
    submit.disabled = true;
    submit.textContent = mode === "register" ? "Creating account…" : "Logging in…";
    status.textContent = ""; delete status.dataset.kind;
    try {
      const result = await apiRequest(endpoint, { method: "POST", body: JSON.stringify(values) });
      status.dataset.kind = "success";
      status.textContent = mode === "register" ? "Account created. Opening your workspace…" : "Login successful. Opening your workspace…";
      window.location.assign("/app.html#dashboard");
    } catch (error) {
      status.dataset.kind = "error";
      status.textContent = error.message || "The request could not be completed.";
    } finally {
      submit.disabled = false;
      submit.innerHTML = mode === "register" ? 'Create account <span>→</span>' : 'Log in <span>→</span>';
    }
  });
}
