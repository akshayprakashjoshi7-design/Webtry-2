Generate migrations with `npm run db:migrate` against a configured development database, review the SQL, and commit timestamped migration directories. This README is not a migration.
