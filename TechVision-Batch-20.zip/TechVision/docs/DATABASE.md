# Database — Batch 2

The Prisma schema defines account/session models plus planned learning, quiz, certificate, project, repository, deployment, terminal, execution, lab, tool, notification, bookmark, and audit records. Schema models do not imply every workflow is implemented.

```bash
npm install
npm run db:generate
npm run db:migrate
npm run db:seed
```

Review and commit generated migration SQL. Use `npm run db:deploy` for production migrations, not `migrate dev`. Passwords are Argon2id hashes; session tokens are stored as SHA-256 hashes. OAuth token fields are placeholders for encrypted values; token encryption and OAuth flows are not implemented yet.
