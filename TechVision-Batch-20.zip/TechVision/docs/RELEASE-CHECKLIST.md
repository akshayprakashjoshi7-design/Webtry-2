# Release checklist

- [ ] Use a supported Node.js LTS release and install locked, reviewed dependencies.
- [ ] Set a strong private `SESSION_SECRET`, HTTPS `APP_BASE_URL`, exact `CORS_ORIGIN`, and production database credentials.
- [ ] Run `npm run db:generate`, `npm run db:migrate` (development) or `npm run db:deploy` (production), and `npm run db:seed`.
- [ ] Configure reverse-proxy TLS, trusted proxy hops, database backups, log retention, monitoring, and error alerting.
- [ ] Add distributed rate limiting before horizontal scaling; in-memory limiters are per process.
- [ ] Perform CSRF review for cookie-authenticated state changes and validate origin policy.
- [ ] Test account/session flows, authorization boundaries, privacy, accessibility, migrations, and restore procedures.
- [ ] Never expose secrets in frontend code, source control, logs, error messages, or client bundles.
- [ ] Keep terminal execution disabled until an independently isolated worker and security review are complete.
