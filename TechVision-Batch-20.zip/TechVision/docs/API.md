# API reference

## Authentication

- `POST /api/auth/register` — create an account and session.
- `POST /api/auth/login` — authenticate and create a session.
- `POST /api/auth/logout` — revoke the current session and clear its cookie.
- `GET /api/auth/me` — retrieve the authenticated public user.
- `PATCH /api/auth/profile` — update profile fields; requires authentication.

## Nexora AI (Batch 4)

- `POST /api/ai/chat` — authenticated Gemini-powered learning assistant. Body: `{ "message": "...", "history": [{ "role": "user" | "assistant", "content": "..." }] }`. `history` is optional and limited to 12 messages; combined content is capped at 12,000 characters. Returns `{ "data": { "text": "...", "model": "..." } }`. A missing `GEMINI_API_KEY` returns `503 AI_NOT_CONFIGURED`. Requests are rate-limited.

Session cookies are HttpOnly and should not be copied into localStorage. OAuth, email verification, password reset, MFA, and CSRF token workflow are not implemented. See `AUTHENTICATION.md` and `AI_TUTOR.md` before deployment.
