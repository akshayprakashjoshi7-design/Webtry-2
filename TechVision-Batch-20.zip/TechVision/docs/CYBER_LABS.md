# Cyber Labs — Batch 7

Four browser-based educational simulations: security foundations, DNS troubleshooting, defensive log review, and safe web output handling. Scenarios use fictional data and run locally. There are no target inputs, network probes, exploit payloads, credential collection, shell commands, or external system interactions. These are learning aids, not a real lab environment or security assessment. Persistent scores, instructor authoring, container isolation, and audit events are not included.
