# Code execution gateway — Batch 14

The API server never uses `eval`, `child_process`, a local shell, or an in-process interpreter. Authenticated jobs are forwarded only to a separately operated worker when `EXECUTION_WORKER_URL` and `EXECUTION_WORKER_TOKEN` are configured. The worker contract is a `POST` JSON request containing `jobId`, `language`, `source`, `stdin`, and strict limits; the response must contain `stdout`, `stderr`, `exitCode`, and `durationMs`.

The worker must independently enforce disposable per-job containers, non-root execution, CPU/memory/PID/time/output limits, no network access, read-only base filesystem, ephemeral workspace, seccomp/AppArmor, image pinning, and cleanup. Never point this at a general-purpose server or untrusted public endpoint. Worker implementation and integration testing remain deployment responsibilities; absent configuration returns `503 EXECUTION_DISABLED` and executes nothing.
