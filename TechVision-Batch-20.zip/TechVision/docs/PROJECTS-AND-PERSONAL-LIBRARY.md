# Projects and personal library

Project records store metadata only. They do not imply that source files, Git objects, remote hosting, or deployments exist. All project list/update/delete operations are scoped to the authenticated owner. Bookmarks are unique per user, item type, and target ID. The current generic bookmark endpoint accepts supported target types but does not prove that every target exists; UI actions should only offer valid target IDs.
