# Learning Academy — Batch 6

- `GET /api/learning/courses` lists published courses.
- `GET /api/learning/courses/:slug` returns a published course and lesson content.
- `GET /api/learning/me` returns authenticated enrollments and progress.
- `POST /api/learning/enroll` accepts `{ "courseId": "..." }`.
- `PUT /api/learning/progress` accepts `{ "lessonId": "...", "completed": true|false }`.

Run database generate, migration, and seed after configuring PostgreSQL. Seed includes three sample courses and six lessons. Sample content is not a certification. Course authoring, quizzes, and certificates are not included.
