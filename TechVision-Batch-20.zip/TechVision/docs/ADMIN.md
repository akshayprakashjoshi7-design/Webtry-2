# Admin management — Batch 16

The admin router now supports platform metrics, paginated user listing, user activation/deactivation (deactivation revokes sessions), role assignment for `LEARNER`, `INSTRUCTOR`, and `ADMIN`, course creation/status updates, and audit events. Every mutating action is ADMIN-only and writes an audit record. The app contains a billing navigation placeholder; payment status is never trusted from a client. Seed does not grant ADMIN automatically. Grant it manually using a reviewed, direct database operation and protect that procedure.
