# Terminal Lab

The current terminal is a command simulator, not a shell. It implements a fixed allowlist (`help`, `pwd`, `ls`, `whoami`, `date`, `uname`, `clear`, `echo`, and `cat README.txt`). It does not use `child_process`, spawn a shell, access user files, or execute arbitrary input. A real interactive terminal would require a separately isolated disposable container, a brokered WebSocket gateway, strict egress rules, per-user quotas, and teardown automation; do not connect a host shell directly to this API.
