# TechVision release readiness — Batch 20

## Included in source
- Authentication/session baseline, email-token and password-reset APIs, Google/GitHub OAuth flows.
- Nexora AI server integration, course enrollment/progress APIs, project metadata, bookmarks/notifications, safe terminal simulator, admin endpoints.
- Optional external isolated code-execution gateway (disabled without worker credentials).
- GitHub public repository listing/creation after OAuth.
- Subscription data model and disabled-by-default checkout; signed webhook envelope is only a provider-neutral integration stub.
- Session management, password change, same-origin request guard, PWA shell cache, local PostgreSQL Compose service, CI workflow.

## Must be completed before public production
1. Run `npm install`, `npm run db:generate`, `npm run db:migrate`, `npm run db:seed`, `npm run check`, and `npm test` in a configured environment.
2. Review/generate a migration for schema additions. Test migrations on a disposable database and back up production before applying.
3. Configure real email delivery; remove development-link output by running production mode and test email ownership verification end-to-end.
4. Configure OAuth provider callback URLs and test provider-specific consent/scopes; verify encryption key management and token revocation.
5. Implement and independently audit the sandbox worker. Keep execution disabled until it is isolated and threat-tested.
6. Integrate an actual payment provider's official SDK and webhook verification before enabling billing. No payment is processed here.
7. Configure HTTPS, secure cookies, Redis-backed rate limiting, observability, backups, dependency scanning, incident response, privacy policy, terms, and age-appropriate community safeguards.
8. Add MFA/TOTP, email change confirmation, account deletion/export, robust CSRF tests, and professional security review.

## Honest capability boundaries
The project is a development foundation, not a certified production service. This batch has not run database migrations, live OAuth, email delivery, worker execution, payment processing, or browser E2E tests. UI links and data models do not mean external providers are configured. The code execution API never runs source inside the web process. Terminal Lab remains a simulator. GitHub support creates public repositories only and does not deploy projects.
