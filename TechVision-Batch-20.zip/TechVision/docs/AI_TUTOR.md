# Nexora AI tutor — Batch 4

## API

`POST /api/ai/chat` requires a valid TechVision session cookie and accepts JSON:

```json
{
  "message": "Explain DNS in simple terms",
  "history": [
    { "role": "user", "content": "What is a domain name?" },
    { "role": "assistant", "content": "A domain name is a readable name for a service on the internet." }
  ]
}
```

The response shape is `{ "data": { "text": "...", "model": "gemini-3.8-flash" } }`. History is sent by the browser and is not stored by this app in a database. The endpoint validates the message and history, limits requests, and uses the Gemini key only on the server. The default model can be changed using `GEMINI_MODEL`.

## Configure

Set `GEMINI_API_KEY` in the private server-side `.env` file. Never put this key in HTML, CSS, or browser JavaScript and never commit `.env`. A missing key produces `503 AI_NOT_CONFIGURED`. The endpoint requires an authenticated account and an active database-backed session.

## Privacy and limitations

- Messages are sent to the AI provider configured by the server. Do not submit passwords, API keys, sensitive personal details, or confidential source code.
- The current conversation history exists in browser memory only and is sent with subsequent prompts. It is not persisted by TechVision, but provider data handling depends on the provider's current terms and settings.
- The per-process rate limiter is suitable only as a development safeguard. Production should use a shared limiter/store, quotas, monitoring, and abuse controls.
- The tutor system instruction encourages safe, authorized defensive cybersecurity learning but is not a substitute for supervision, review, or a complete safety system.
- The API key is supplied to Google's Gemini API by a server-side HTTPS request. Review current provider policies, data settings, pricing, and model availability before production use.
- No streaming, attachments, conversation database, moderation dashboard, or per-user usage billing is included in this batch.
