# Feature status (updated through Batch 12)

| Feature | Status | Notes |
|---|---|---|
| Account registration/login | Implemented, needs runtime verification | Cookie sessions and password hashing; email verification and password reset not enabled |
| Nexora AI | Implemented behind server API, needs live-key test | Requires configured Gemini credentials |
| Learning Academy | API and sample content | Requires database migration/seed and integration tests |
| Code Studio | Browser editor/preview features | No server-side execution or publishing pipeline |
| Cyber Labs | Fictional defensive simulations | Does not connect to real targets |
| Terminal Lab | Safe command simulator | No real shell execution |
| Projects | Metadata CRUD | No file content storage, Git engine, or remote host |
| Bookmarks | API and UI for project bookmarks | Generic bookmark targets are not independently verified |
| Notifications | Read/list API | No notification delivery pipeline yet |
| Admin overview | Read-only ADMIN-protected endpoints | No account moderation or role management UI |
| Production readiness | Not yet | Must complete release checklist, tests, security review, backups, monitoring, and deployment configuration |
