# Admin operations

The admin API is read-only and protected by the `ADMIN` role returned by the session resolver. It exposes aggregate counts, a paginated user list, and recent audit records. Seeding creates role definitions but deliberately does not promote any account to administrator. Granting admin access should be a controlled, audited, out-of-band operation after verifying the operator's identity. Do not add a public admin-registration endpoint.

The current overview is not a complete moderation portal. User suspension, role changes, content publishing, billing, and destructive administrative actions are not exposed.
