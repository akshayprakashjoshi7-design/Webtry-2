# GitHub integration — Batch 18

After GitHub OAuth, `GET /api/projects/github` lists the user's public repositories and `POST /api/projects/github` creates a **public** repository. Access tokens are encrypted at rest with AES-GCM. This feature does not clone repositories, read private repositories, upload local project files, run CI, or deploy apps. Scope defaults to `public_repo`; review provider permissions before enabling. Revoke the OAuth app if a token is suspected compromised.
