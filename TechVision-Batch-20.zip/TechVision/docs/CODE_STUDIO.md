# Code Studio — Batch 5

HTML, CSS, and JavaScript editor tabs with starter templates, browser-local draft persistence, and download-current-file. Preview uses an iframe with `sandbox="allow-scripts"` and no `allow-same-origin`; it does not execute code on the server. Browser local storage is not account sync. Do not store secrets. Syntax highlighting, collaboration, Git, compiling, and publishing are not included.
