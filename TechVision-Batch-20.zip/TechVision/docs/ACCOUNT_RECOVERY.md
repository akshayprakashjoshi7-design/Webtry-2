# Account verification and recovery — Batch 13

Routes: `POST /api/account/verification/request`, `POST /api/account/verification/confirm`, `POST /api/account/password/forgot`, `POST /api/account/password/reset`.

Tokens are cryptographically random, stored as SHA-256 hashes, time-limited, and consumed once. Password reset revokes existing sessions. In development, links are returned in the response and logged for local testing; production deliberately does not expose links. **Production email delivery is not wired**: connect an approved email provider before claiming email delivery works. Passwords are Argon2id hashes. Configure HTTPS, request limits backed by a shared store, monitoring, and account-abuse controls before public launch.
