# Authentication — Batch 2

## Implemented source
- Email/password registration and login.
- Argon2id password hashes.
- Random opaque session tokens; only SHA-256 hashes are stored in PostgreSQL.
- HttpOnly, SameSite=Lax cookie; Secure in production.
- Session expiration and revocation.
- Current-user and profile endpoints.
- Zod validation, generic invalid-credentials message, authentication rate limiting.
- Role middleware for later protected APIs.

## Setup
1. Install Node.js 20+ and PostgreSQL.
2. Copy `.env.example` to `.env` and set `DATABASE_URL`.
3. Run `npm install`, `npm run db:generate`, `npm run db:migrate`, and `npm run db:seed`.
4. Start with `npm run dev`.

## Endpoints
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `PATCH /api/auth/profile`

Email verification, reset-email delivery, MFA, OAuth callbacks, CSRF token workflow, shared rate-limit storage, and session management UI are not implemented yet. The current rate limiter is in-memory and needs a shared store for multi-instance deployments. Configure reverse proxies carefully before trusting client IP values. No admin user is automatically created.
