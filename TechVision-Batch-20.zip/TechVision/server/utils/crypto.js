import {createHash,randomBytes} from "node:crypto";
export const createOpaqueToken=(bytes=32)=>randomBytes(bytes).toString("base64url");
export const hashToken=(token)=>createHash("sha256").update(token,"utf8").digest("hex");
