import {env} from "../config/env.js";
import {SESSION_COOKIE} from "./authenticate.js";
export function setSessionCookie(res,token,expiresAt){res.cookie(SESSION_COOKIE,token,{httpOnly:true,secure:env.nodeEnv==="production",sameSite:"lax",path:"/",expires:expiresAt});}
export function clearSessionCookie(res){res.clearCookie(SESSION_COOKIE,{httpOnly:true,secure:env.nodeEnv==="production",sameSite:"lax",path:"/"});}
