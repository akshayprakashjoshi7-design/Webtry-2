import {getUserForSession} from "../services/auth.service.js";
export const SESSION_COOKIE="tv_session";
export async function optionalAuthenticate(req,_res,next){try{const token=req.cookies?.[SESSION_COOKIE];if(token){const found=await getUserForSession(token);if(found){req.user=found.user;req.sessionId=found.sessionId;req.sessionToken=token;}}next();}catch(e){next(e);}}
export function requireAuth(req,res,next){if(!req.user)return res.status(401).json({error:{code:"AUTHENTICATION_REQUIRED",message:"Please log in to continue."}});next();}
export function requireRole(...roles){return(req,res,next)=>{if(!req.user)return res.status(401).json({error:{code:"AUTHENTICATION_REQUIRED",message:"Please log in to continue."}});if(!req.user.roles.some(r=>roles.includes(r)))return res.status(403).json({error:{code:"FORBIDDEN",message:"You do not have permission to perform this action."}});next();};}
