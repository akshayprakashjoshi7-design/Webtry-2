import { env } from "../config/env.js";
const unsafe=new Set(["POST","PUT","PATCH","DELETE"]);
const allowed=new Set([env.appBaseUrl,env.corsOrigin].map(value=>{try{return new URL(value).origin}catch{return ""}}).filter(Boolean));
export function csrfOriginGuard(req,res,next){if(!unsafe.has(req.method)||!req.cookies?.tv_session)return next();const origin=req.get("origin");const fetchSite=req.get("sec-fetch-site");if(fetchSite==="cross-site"||!origin||!allowed.has(origin)){return res.status(403).json({error:{code:"CSRF_ORIGIN_REJECTED",message:"Request origin could not be verified. Reload the app and try again."}})}next();}
