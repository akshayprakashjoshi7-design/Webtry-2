import { Router } from "express";
import rateLimit from "express-rate-limit";
import { optionalAuthenticate, requireAuth } from "../middleware/authenticate.js";
import { createExecutionSchema } from "../validators/execution.validators.js";
import { executeThroughGateway, getExecutionJob } from "../services/execution.service.js";
export const executionRouter=Router();
executionRouter.use(rateLimit({windowMs:60_000,limit:8,standardHeaders:"draft-8",legacyHeaders:false}),optionalAuthenticate,requireAuth);
executionRouter.post("/jobs",async(req,res,next)=>{const p=createExecutionSchema.safeParse(req.body);if(!p.success)return res.status(400).json({error:{code:"VALIDATION_ERROR",message:"Use a supported language and source within 20,000 characters."}});try{res.status(202).json({data:{job:await executeThroughGateway(req.user.id,p.data),notice:"Source is sent only to the configured isolated worker; this API server never executes it."}})}catch(e){next(e)}});
executionRouter.get("/jobs/:id",async(req,res,next)=>{try{const job=await getExecutionJob(req.user.id,req.params.id);if(!job)return res.status(404).json({error:{code:"JOB_NOT_FOUND",message:"Execution job not found."}});res.set("Cache-Control","no-store").json({data:{job}})}catch(e){next(e)}});
