import {Router} from "express";
import rateLimit from "express-rate-limit";
import {optionalAuthenticate,requireAuth} from "../middleware/authenticate.js";
import {createProjectSchema,updateProjectSchema} from "../validators/projects.validators.js";
import {createProject,deleteProject,listProjects,updateProject} from "../services/projects.service.js";
import {listGitHubRepos,createGitHubRepo} from "../services/github.service.js";
import {z} from "zod";
export const projectsRouter=Router();
const limiter=rateLimit({windowMs:60_000,limit:40,standardHeaders:"draft-8",legacyHeaders:false});
projectsRouter.use(limiter,optionalAuthenticate,requireAuth);
projectsRouter.get("/",async(req,res,next)=>{try{res.set("Cache-Control","no-store").json({data:{projects:await listProjects(req.user.id),notice:"Repository metadata only; file storage, Git operations, and remote hosting are not connected."}})}catch(e){next(e)}});
projectsRouter.post("/",async(req,res,next)=>{const p=createProjectSchema.safeParse(req.body);if(!p.success)return res.status(400).json({error:{code:"VALIDATION_ERROR",message:"Check project fields."}});try{res.status(201).json({data:{project:await createProject(req.user.id,p.data)}})}catch(e){next(e)}});
projectsRouter.patch("/:id",async(req,res,next)=>{const p=updateProjectSchema.safeParse(req.body);if(!p.success)return res.status(400).json({error:{code:"VALIDATION_ERROR",message:"Provide at least one valid project field."}});try{const r=await updateProject(req.user.id,req.params.id,p.data);if(!r.count)return res.status(404).json({error:{code:"PROJECT_NOT_FOUND",message:"Project not found."}});res.json({data:{updated:true}})}catch(e){next(e)}});
projectsRouter.delete("/:id",async(req,res,next)=>{try{const r=await deleteProject(req.user.id,req.params.id);if(!r.count)return res.status(404).json({error:{code:"PROJECT_NOT_FOUND",message:"Project not found."}});res.status(204).end()}catch(e){next(e)}});

projectsRouter.get("/github",async(req,res,next)=>{try{const repos=await listGitHubRepos(req.user.id);res.set("Cache-Control","no-store").json({data:{repositories:repos,notice:"GitHub repositories are listed read-only. Only public repositories are requested."}})}catch(e){next(e)}});
projectsRouter.post("/github",async(req,res,next)=>{const p=z.object({name:z.string().trim().min(1).max(100).regex(/^[A-Za-z0-9_.-]+$/),description:z.string().trim().max(350)}).safeParse(req.body);if(!p.success)return res.status(400).json({error:{code:"VALIDATION_ERROR",message:"Repository name or description is invalid."}});try{const repository=await createGitHubRepo(req.user.id,p.data);res.status(201).json({data:{repository}})}catch(e){next(e)}});
