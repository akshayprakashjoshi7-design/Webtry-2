import { Router } from "express";
import rateLimit from "express-rate-limit";
import { optionalAuthenticate, requireAuth } from "../middleware/authenticate.js";
import { generateTutorReply } from "../services/ai.service.js";
import { aiChatSchema } from "../validators/ai.validators.js";

export const aiRouter = Router();
const chatLimiter = rateLimit({
  windowMs: 60_000,
  limit: 12,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: { code: "AI_RATE_LIMITED", message: "Too many AI requests. Please wait a minute and try again." } }
});

aiRouter.post("/chat", chatLimiter, optionalAuthenticate, requireAuth, async (req, res, next) => {
  const parsed = aiChatSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({
      error: {
        code: "VALIDATION_ERROR",
        message: "Please check your message and conversation length.",
        details: parsed.error.issues.map(issue => ({ field: issue.path.join("."), message: issue.message }))
      }
    });
  }
  try {
    const result = await generateTutorReply(parsed.data);
    res.set("Cache-Control", "no-store").json({ data: result });
  } catch (error) { next(error); }
});
