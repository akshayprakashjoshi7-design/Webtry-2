import { createApp } from "./app.js";
import { env, validateStartupConfig } from "./config/env.js";
import { prisma } from "./config/database.js";

validateStartupConfig();
const app = createApp();
const server = app.listen(env.port, () => {
  console.log(`TechVision listening at ${env.appBaseUrl}`);
  console.log(`API health: ${env.appBaseUrl}/api/health`);
});

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`${signal} received; closing TechVision...`);
  server.close(async (error) => {
    if (error) { console.error("HTTP server shutdown error."); process.exitCode = 1; }
    await prisma.$disconnect().catch(() => {});
  });
  setTimeout(() => { console.error("Shutdown timed out."); process.exit(1); }, 10000).unref();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
