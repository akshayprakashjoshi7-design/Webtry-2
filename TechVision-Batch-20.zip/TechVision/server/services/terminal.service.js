import { prisma } from "../config/database.js";
const HELP = "Available demo commands: help, pwd, ls, whoami, date, uname, clear, echo <text>, cat README.txt. This is a simulator; commands never run on a real shell.";
const FILES = { "README.txt": "TechVision Terminal Lab\nA safe command-line concepts simulator. No shell is connected.\nPractice only in systems you own or are authorized to use." };
export function simulateCommand(raw) {
 const input = String(raw || "").trim(); const [cmd, ...rest] = input.split(/\s+/); const arg = rest.join(" ");
 switch (cmd) {
  case "help": return HELP;
  case "pwd": return "/home/learner/workspace (simulated)";
  case "ls": return "README.txt  notes/  projects/  (simulated entries)";
  case "whoami": return "learner (simulated user)";
  case "date": return new Date().toISOString() + " (server clock)";
  case "uname": return "TechVision-Lab simulated-environment 1.0";
  case "clear": return "__CLEAR__";
  case "echo": return arg.slice(0, 1200);
  case "cat": return FILES[arg] || "File not found in the simulated workspace. Try: cat README.txt";
  default: return `Command not available in this safe simulator: ${cmd}. Type help to see the allowlist.`;
 }
}
export async function createTerminalSession(userId) {
 return prisma.terminalSession.create({ data: { userId, environment: "safe-command-simulator", status: "ACTIVE", expiresAt: new Date(Date.now()+30*60*1000) }, select: { id:true, environment:true, status:true, expiresAt:true, createdAt:true } });
}
export async function listTerminalSessions(userId) {
 return prisma.terminalSession.findMany({ where:{userId}, orderBy:{createdAt:"desc"}, take:10, select:{id:true,environment:true,status:true,expiresAt:true,createdAt:true,endedAt:true} });
}
export async function endTerminalSession(userId,id) {
 return prisma.terminalSession.updateMany({ where:{id,userId,status:"ACTIVE"}, data:{status:"ENDED",endedAt:new Date()} });
}
