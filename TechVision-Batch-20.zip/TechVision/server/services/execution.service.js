import { createHash } from "node:crypto";
import { prisma } from "../config/database.js";
import { env } from "../config/env.js";
const digest = value => createHash("sha256").update(value).digest("hex");
export async function executeThroughGateway(userId, input) {
  if (!env.executionWorkerUrl || !env.executionWorkerToken) { const e=new Error("Secure execution worker is not configured. No code was executed."); e.status=503; e.code="EXECUTION_DISABLED"; throw e; }
  const job = await prisma.executionJob.create({ data: { userId, language: input.language, status: "RUNNING", sourceHash: digest(input.source) } });
  const controller = new AbortController(); const timer=setTimeout(()=>controller.abort(), 12000);
  try {
    const response=await fetch(env.executionWorkerUrl,{method:"POST",headers:{"content-type":"application/json","authorization":`Bearer ${env.executionWorkerToken}`},body:JSON.stringify({jobId:job.id,language:input.language,source:input.source,stdin:input.stdin,limits:{cpuMs:2000,memoryMb:128,wallMs:8000,network:false,filesystem:"ephemeral-readonly-base",maxOutputBytes:16000}}),signal:controller.signal});
    if(!response.ok) throw new Error(`Execution worker returned ${response.status}`);
    const result=await response.json();
    const safe={stdout:String(result.stdout??"").slice(0,8000),stderr:String(result.stderr??"").slice(0,8000),exitCode:Number.isInteger(result.exitCode)?result.exitCode:null, durationMs:Math.min(12000,Math.max(0,Number(result.durationMs)||0))};
    await prisma.executionJob.update({where:{id:job.id},data:{status:"COMPLETED",resultJson:safe,durationMs:safe.durationMs,finishedAt:new Date()}});
    return {id:job.id,...safe,status:"COMPLETED"};
  } catch(error) {
    await prisma.executionJob.update({where:{id:job.id},data:{status:"FAILED",resultJson:{error:"Execution worker unavailable."},finishedAt:new Date()}}).catch(()=>{});
    const e=new Error(error.name==="AbortError"?"Execution timed out.":"Execution worker is unavailable."); e.status=502; e.code="WORKER_UNAVAILABLE"; throw e;
  } finally { clearTimeout(timer); }
}
export async function getExecutionJob(userId,id) { return prisma.executionJob.findFirst({where:{id,userId},select:{id:true,language:true,status:true,resultJson:true,durationMs:true,createdAt:true,finishedAt:true}}); }
