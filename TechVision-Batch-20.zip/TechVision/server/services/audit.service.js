import {prisma} from "../config/database.js";
export async function writeAuditLog({actorId=null,action,targetType=null,targetId=null,requestId=null,metadata=null}){return prisma.auditLog.create({data:{actorId,action,targetType,targetId,requestId,metadata:metadata??undefined}})}
