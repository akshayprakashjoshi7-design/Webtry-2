const MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";
const API_BASE = "https://generativelanguage.googleapis.com/v1beta/models";

const SYSTEM_INSTRUCTION = `You are Nexora, the TechVision learning assistant. Help learners understand programming, web development, Linux, networking, mathematics, and defensive cybersecurity. Be accurate, friendly, and clear; explain concepts step by step and say when you are uncertain. For cybersecurity, prioritize lawful defensive learning, consent, and intentionally vulnerable labs the learner owns or is authorized to test. Do not provide instructions to break into real accounts or systems, steal credentials, evade detection, deploy malware, or invade someone's privacy. Redirect such requests toward safe lab simulations, threat awareness, and defensive mitigations. Do not ask users to share passwords, API keys, private identifiers, or sensitive personal information. Do not claim you executed code, inspected a system, or verified live facts unless that actually occurred. Keep responses reasonably concise and use Markdown when helpful.`;

export async function generateTutorReply({ message, history = [] }) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    const error = new Error("Nexora AI is not configured yet. Add GEMINI_API_KEY to the server environment.");
    error.status = 503;
    error.code = "AI_NOT_CONFIGURED";
    throw error;
  }

  const contents = [
    ...history.map(({ role, content }) => ({ role: role === "assistant" ? "model" : "user", parts: [{ text: content }] })),
    { role: "user", parts: [{ text: message }] }
  ];

  let response;
  try {
    response = await fetch(`${API_BASE}/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(apiKey)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
        contents,
        generationConfig: { maxOutputTokens: 1200 }
      }),
      signal: AbortSignal.timeout(30000)
    });
  } catch {
    const error = new Error("Nexora AI could not reach the model service. Please try again shortly.");
    error.status = 502;
    error.code = "AI_UPSTREAM_UNAVAILABLE";
    throw error;
  }

  if (!response.ok) {
    // Do not return upstream payloads: they may include provider diagnostics or request details.
    const status = response.status === 429 ? 429 : response.status === 401 || response.status === 403 ? 503 : 502;
    const error = new Error(status === 429
      ? "The AI service is busy. Please wait a moment and try again."
      : status === 503
        ? "The AI provider rejected the server configuration. Check the API key and model access."
        : "The AI provider returned an error. Please try again later.");
    error.status = status;
    error.code = status === 429 ? "AI_PROVIDER_RATE_LIMITED" : "AI_PROVIDER_ERROR";
    throw error;
  }

  let payload;
  try { payload = await response.json(); }
  catch {
    const error = new Error("The AI provider returned an unreadable response.");
    error.status = 502;
    error.code = "AI_INVALID_RESPONSE";
    throw error;
  }

  const candidate = payload?.candidates?.[0];
  const text = candidate?.content?.parts?.map(part => part.text || "").join("").trim();
  if (!text) {
    const error = new Error(candidate?.finishReason === "SAFETY"
      ? "That request could not be answered. Try asking in a different, safety-focused way."
      : "Nexora did not receive a usable answer. Please try again.");
    error.status = 502;
    error.code = "AI_EMPTY_RESPONSE";
    throw error;
  }
  return { text, model: MODEL };
}
