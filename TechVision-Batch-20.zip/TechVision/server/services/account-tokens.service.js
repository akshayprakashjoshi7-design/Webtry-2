import { prisma } from "../config/database.js";
import { createOpaqueToken, hashToken } from "../utils/crypto.js";

const VERIFY_TTL_MS = 30 * 60 * 1000;
const RESET_TTL_MS = 20 * 60 * 1000;
export async function issueEmailVerification(userId) {
  const raw = createOpaqueToken();
  const expiresAt = new Date(Date.now() + VERIFY_TTL_MS);
  await prisma.emailVerificationToken.create({ data: { userId, tokenHash: hashToken(raw), expiresAt } });
  return { raw, expiresAt };
}
export async function verifyEmail(raw) {
  if (typeof raw !== "string" || raw.length > 200) return false;
  const token = await prisma.emailVerificationToken.findUnique({ where: { tokenHash: hashToken(raw) } });
  if (!token || token.consumedAt || token.expiresAt <= new Date()) return false;
  return prisma.$transaction(async tx => {
    const claimed = await tx.emailVerificationToken.updateMany({ where: { id: token.id, consumedAt: null, expiresAt: { gt: new Date() } }, data: { consumedAt: new Date() } });
    if (!claimed.count) return false;
    await tx.user.update({ where: { id: token.userId }, data: { emailVerifiedAt: new Date() } });
    return true;
  });
}
export async function issuePasswordReset(email) {
  const user = await prisma.user.findUnique({ where: { email }, select: { id: true, isActive: true } });
  if (!user || !user.isActive) return null;
  const raw = createOpaqueToken();
  const expiresAt = new Date(Date.now() + RESET_TTL_MS);
  await prisma.passwordResetToken.create({ data: { userId: user.id, tokenHash: hashToken(raw), expiresAt } });
  return { raw, expiresAt, userId: user.id };
}
export async function consumePasswordReset(raw, passwordHash) {
  if (typeof raw !== "string" || raw.length > 200) return false;
  const token = await prisma.passwordResetToken.findUnique({ where: { tokenHash: hashToken(raw) } });
  if (!token || token.consumedAt || token.expiresAt <= new Date()) return false;
  return prisma.$transaction(async tx => {
    const claimed = await tx.passwordResetToken.updateMany({ where: { id: token.id, consumedAt: null, expiresAt: { gt: new Date() } }, data: { consumedAt: new Date() } });
    if (!claimed.count) return false;
    await tx.user.update({ where: { id: token.userId }, data: { passwordHash } });
    await tx.session.updateMany({ where: { userId: token.userId, revokedAt: null }, data: { revokedAt: new Date() } });
    return true;
  });
}
