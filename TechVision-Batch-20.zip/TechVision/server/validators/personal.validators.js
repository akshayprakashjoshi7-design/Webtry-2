import {z} from "zod";
export const bookmarkSchema=z.object({targetType:z.enum(["COURSE","PROJECT","LESSON","RESOURCE"]),targetId:z.string().trim().min(1).max(180)});
