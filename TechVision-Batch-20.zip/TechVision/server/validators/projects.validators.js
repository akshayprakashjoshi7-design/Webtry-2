import { z } from "zod";
const name=z.string().trim().min(2).max(180);
export const createProjectSchema=z.object({name,description:z.string().trim().max(2000).optional().default(""),language:z.string().trim().max(40).optional().default(""),visibility:z.enum(["PRIVATE","PUBLIC","UNLISTED"]).optional().default("PRIVATE")});
export const updateProjectSchema=z.object({name:name.optional(),description:z.string().trim().max(2000).optional(),language:z.string().trim().max(40).optional(),visibility:z.enum(["PRIVATE","PUBLIC","UNLISTED"]).optional()}).refine(v=>Object.keys(v).length>0);
