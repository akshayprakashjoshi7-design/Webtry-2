import { z } from "zod";
export const createExecutionSchema = z.object({ language: z.enum(["javascript","python","html"]), source: z.string().min(1).max(20000), stdin: z.string().max(4000).optional().default("") });
