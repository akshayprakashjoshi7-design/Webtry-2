import { z } from "zod";
export const slugSchema = z.string().trim().min(1).max(180).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/);
export const enrollmentSchema = z.object({ courseId: z.string().trim().min(1).max(64) }).strict();
export const lessonProgressSchema = z.object({ lessonId: z.string().trim().min(1).max(64), completed: z.boolean() }).strict();
