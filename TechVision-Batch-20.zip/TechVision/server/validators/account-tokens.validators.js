import { z } from "zod";
export const emailSchema = z.object({ email: z.string().trim().toLowerCase().email().max(254) });
export const tokenSchema = z.object({ token: z.string().min(20).max(200) });
export const resetPasswordSchema = z.object({ token: z.string().min(20).max(200), password: z.string().min(12).max(128).regex(/[a-z]/).regex(/[A-Z]/).regex(/[0-9]/) });
