import { z } from "zod";

const chatMessageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string().trim().min(1).max(4000)
}).strict();

export const aiChatSchema = z.object({
  message: z.string().trim().min(1, "Enter a message.").max(4000, "Message is too long."),
  history: z.array(chatMessageSchema).max(12).default([])
}).strict().superRefine((value, ctx) => {
  const total = value.message.length + value.history.reduce((sum, item) => sum + item.content.length, 0);
  if (total > 12000) ctx.addIssue({ code: "custom", message: "This conversation is too long. Start a new chat." });
});
