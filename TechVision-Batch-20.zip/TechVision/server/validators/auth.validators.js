import {z} from "zod";
const email=z.string().trim().email().max(254).transform(v=>v.toLowerCase());
export const registerSchema=z.object({email,password:z.string().min(12,"Password must be at least 12 characters.").max(128).refine(v=>!/^[\s]+$/.test(v),"Password cannot contain only whitespace."),displayName:z.string().trim().min(2).max(60).optional()}).strict();
export const loginSchema=z.object({email,password:z.string().min(1).max(128)}).strict();
export const updateProfileSchema=z.object({displayName:z.string().trim().min(2).max(60).optional(),bio:z.string().trim().max(500).optional(),learningInterests:z.array(z.string().trim().min(1).max(50)).max(20).optional()}).strict().refine(v=>Object.keys(v).length>0,"Provide at least one profile field.");
