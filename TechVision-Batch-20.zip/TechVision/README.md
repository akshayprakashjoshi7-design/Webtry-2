# TechVision

TechVision is a learning, coding, development, and authorized cybersecurity platform.

## Batches
- Batch 1: responsive homepage, shared styles, Express server, health endpoint.
- Batch 2: Prisma schema, Argon2id authentication services, server-side opaque sessions, logout, current-user and profile endpoints.
- Batch 3: responsive workspace UI, login/registration pages, dashboard and account settings.
- Batch 4: Nexora AI chat API using server-side Gemini, authenticated requests, validation/rate limits, and responsive chat UI.

These are source implementations; runtime depends on installing packages, configuring PostgreSQL, applying migrations, and running tests.

## Setup
1. Copy `.env.example` to `.env` and configure `DATABASE_URL`.
2. `npm install`
3. `npm run db:generate`
4. `npm run db:migrate`
5. `npm run db:seed`
6. `npm run dev`
7. Open `http://localhost:3000` and `/api/health`.

Run `npm run check` and `npm test`. Auth routes require a configured database and applied schema.

## Auth endpoints
`POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me`, `PATCH /api/auth/profile`, and authenticated `POST /api/ai/chat`.

## Limitations
Email verification, password reset delivery, MFA, OAuth, CSRF token workflow, learning workflows, quizzes, certificates, code execution, terminal sessions, lab execution, repository operations, and publishing are not yet implemented. Nexora AI source is present, but live responses require a valid server-side `GEMINI_API_KEY` and runtime verification. Never advertise these as operational.

Never commit `.env` or real credentials. Production needs HTTPS, correctly configured proxies, a shared rate-limit store, CSRF defenses, monitoring, and reviewed deployment controls. Never execute untrusted code in the API process.


## Batch 3 — workspace UI

Batch 3 adds the responsive signed-in workspace shell (`app.html`), dashboard, route-based learning/studio/lab/repository/AI/terminal previews, profile settings, and email/password login and registration pages. The UI uses the existing `/api/auth` endpoints and same-origin session cookie.

Run `npm run dev` after configuring `.env`, installing dependencies, generating Prisma Client, and applying database migrations. Open `/` for the marketing page, `/signup.html` to create an account, `/login.html` to log in, or `/app.html` for the workspace. Authentication will only work when the database is configured and migrations have been applied.

**Feature status:** the dashboard clearly labels planned services as previews. Course delivery, AI responses, repository operations, terminal access, and code execution are not implemented by this batch. Do not expose API keys in browser code or connect a shell directly to the web server.

## Batch 4 — Nexora AI

Set `GEMINI_API_KEY` in `.env` to enable the authenticated Nexora AI tutor. Optional `GEMINI_MODEL` defaults to `gemini-3.8-flash`. See `docs/AI_TUTOR.md` for the endpoint, configuration, privacy notes, and limitations. Chat history is held in browser memory and is sent to the configured provider; TechVision does not persist the conversation in this batch.


## Batches 5–7
- **Code Studio:** local HTML/CSS/JS drafts and isolated iframe preview. No server-side execution or publishing.
- **Learning Academy:** course catalog, course detail, enrollment, and lesson-progress APIs. Run migrations and seed after configuring PostgreSQL.
- **Cyber Labs:** local educational simulations only; no real-target scanning, exploitation, or terminal access.

Recommended verification: `npm install`, `npm run db:generate`, `npm run db:migrate`, `npm run db:seed`, `npm run check`, and `npm test`. These commands have not all been run against a configured database in this environment.


## Batches 8–12 additions

- **Batch 8:** Authenticated safe terminal command simulator. It does not execute operating-system commands.
- **Batch 9:** Authenticated project metadata CRUD. File storage, Git, and remote hosting remain unimplemented.
- **Batch 10:** Bookmarks and notification list/read APIs.
- **Batch 11:** Read-only ADMIN overview, user list, and audit log endpoints. No administrator is created by seed.
- **Batch 12:** Release checklist, feature documentation, and expanded syntax-check command.

Run `npm run check` for syntax checks. Database migrations and runtime integration still require a configured PostgreSQL instance and installed dependencies.


## Batches 13–20
- **13:** one-time email verification and password-reset token APIs; dev-only links until a mail provider is connected.
- **14:** authenticated execution-job API that forwards code only to a separately configured isolated worker; disabled by default.
- **15:** Google/GitHub OAuth state validation and AES-GCM token encryption.
- **16:** admin user status/role and course management APIs, audit events, plan/billing UI placeholder.
- **17:** subscription/payment-event schema and disabled-by-default billing webhook foundation; no payment processing.
- **18:** GitHub public repository listing/creation after OAuth.
- **19:** session listing/revocation, password change, and same-origin guard for authenticated unsafe requests.
- **20:** PWA shell caching, local PostgreSQL Compose service, CI workflow, and release-readiness guide.

See `docs/RELEASE_READINESS.md` before deployment. All 20 batches are a feature-complete development foundation only where explicitly implemented; provider integrations require real credentials and validation. **Do not claim production readiness until migrations, runtime tests, external service tests, and a security audit pass.**
