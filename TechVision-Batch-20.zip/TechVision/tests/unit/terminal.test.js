import test from "node:test";
import assert from "node:assert/strict";
import {simulateCommand} from "../../server/services/terminal.service.js";
test("safe terminal supports help and common simulated commands",()=>{assert.match(simulateCommand("help"),/simulator/);assert.match(simulateCommand("pwd"),/simulated/);assert.equal(simulateCommand("echo hello"),"hello");});
test("safe terminal rejects arbitrary shell commands without execution",()=>{assert.match(simulateCommand("rm -rf /"),/not available/);assert.match(simulateCommand("curl https://example.com"),/not available/);});
test("safe terminal reads only the simulated README",()=>{assert.match(simulateCommand("cat README.txt"),/safe command-line/);assert.match(simulateCommand("cat /etc/passwd"),/File not found/);});
