import test from "node:test";
import assert from "node:assert/strict";
process.env.SESSION_SECRET="test-secret-that-is-long-enough-for-unit-tests-123456";
const {encryptToken,decryptToken}=await import("../../server/utils/token-encryption.js");
test("OAuth token encryption round trips",()=>{const encrypted=encryptToken("sample-provider-token");assert.notEqual(encrypted,"sample-provider-token");assert.equal(decryptToken(encrypted),"sample-provider-token")});
test("encrypted tokens reject tampering",()=>{const encrypted=encryptToken("sample-provider-token");assert.throws(()=>decryptToken(encrypted.slice(0,-1)+"A"))});
