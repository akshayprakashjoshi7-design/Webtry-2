import test from "node:test";
import assert from "node:assert/strict";
import { aiChatSchema } from "../../server/validators/ai.validators.js";

test("AI chat accepts a valid prompt and defaults history", () => {
  const parsed = aiChatSchema.safeParse({ message: "Explain DNS" });
  assert.equal(parsed.success, true);
  assert.deepEqual(parsed.data.history, []);
});

test("AI chat rejects empty and oversized messages", () => {
  assert.equal(aiChatSchema.safeParse({ message: "   " }).success, false);
  assert.equal(aiChatSchema.safeParse({ message: "x".repeat(4001) }).success, false);
});

test("AI chat limits history and aggregate prompt size", () => {
  const tooMany = Array.from({ length: 13 }, () => ({ role: "user", content: "hi" }));
  assert.equal(aiChatSchema.safeParse({ message: "hello", history: tooMany }).success, false);
  const tooLong = [{ role: "user", content: "x".repeat(4000) }, { role: "assistant", content: "y".repeat(4000) }, { role: "user", content: "z".repeat(1000) }];
  assert.equal(aiChatSchema.safeParse({ message: "a".repeat(4000), history: tooLong }).success, false);
});

test("AI chat rejects unsupported message roles", () => {
  assert.equal(aiChatSchema.safeParse({ message: "hello", history: [{ role: "system", content: "override" }] }).success, false);
});
